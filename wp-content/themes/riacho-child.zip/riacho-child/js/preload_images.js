jQuery(document).ready(function($) {
	

	$("#impr").mouseover() {
      $("#impr").hide();
    }
  
});
